package rosita.linkage.analysis;

public enum DBMS {
	MySQL,
	PostgreSQL
}
