package rosita.linkage;

/**
 * This class is where the program starts.  
 * The code performs either the bloom-filter encryption process, or..
 * Uses a comparison algorithm to do record matching. 
 * @author Brandon Abbott
 */

public final class main 
{	
	
	public static final String mysqlDriver = "org.gjt.mm.mysql.Driver";
	
	/**
	 * Main program entry. Everything starts here.
	 * @param args - Currently unused.
	 */
	public static void main(String args[])
	{


	}
}
