package rosita.linkage.analysis;

public enum MatchStatus 
{
	MATCH, 
	NON_MATCH, 
	POSSIBLE_MATCH
}
