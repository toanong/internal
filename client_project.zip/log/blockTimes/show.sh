#!/bin/bash
while [ 1 ]; do
clear
cat blockTimes.txt
sleep 2

done
