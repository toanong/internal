
public class PatientFileAttr {
	public static String[] Correct = {"SSN", "firstName", "lastName", "DOB", "sex", "addr", "city", "state", "zip", "phone" };
}
